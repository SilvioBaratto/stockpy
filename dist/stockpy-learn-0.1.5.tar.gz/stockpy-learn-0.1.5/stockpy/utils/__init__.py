from ._dataset import StockDataset
from ._dataset import normalize
